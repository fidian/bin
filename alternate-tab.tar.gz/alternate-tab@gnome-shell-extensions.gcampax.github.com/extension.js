/* -*- mode: js; js-basic-offset: 4; indent-tabs-mode: nil -*- */
/* global imports */

const Lang = imports.lang;
const Meta = imports.gi.Meta;
const Shell = imports.gi.Shell;

const windowSwitcherProto = imports.ui.altTab.WindowSwitcherPopup.prototype;
const Main = imports.ui.main;

let injections = {};

function init(/* metadata */) {
}

function setKeybinding(name, func) {
    Main.wm.setCustomKeybindingHandler(name, Shell.ActionMode.NORMAL, func);
}

function enable() {
    var oldPrimary;
    
    [
        "_getWindowList",
        "_keyPressHandler"
    ].forEach(function (key) {
        injections[key] = windowSwitcherProto[key];
    });
    // Only cycle through apps on current monitor
    // https://www.reddit.com/r/gnome/comments/507bqd/only_feature_im_missing_alttab_filterd_by_monitor/
    windowSwitcherProto._getWindowList = function() {
        let workspace = this._settings.get_boolean('current-workspace-only') ? global.screen.get_active_workspace() : null;
        let allWindows = global.display.get_tab_list(Meta.TabList.NORMAL, workspace);
        allWindows = allWindows.filter(w => w.get_monitor() === global.screen.get_current_monitor());
        return allWindows;
    };
    windowSwitcherProto._keyPressHandler = function(keysym, action) {
        switch(action) {
        case Meta.KeyBindingAction.SWITCH_APPLICATIONS:
        case Meta.KeyBindingAction.SWITCH_GROUP:
            action = Meta.KeyBindingAction.SWITCH_WINDOWS;
            break;
        case Meta.KeyBindingAction.SWITCH_APPLICATIONS_BACKWARD:
        case Meta.KeyBindingAction.SWITCH_GROUP_BACKWARD:
            action = Meta.KeyBindingAction.SWITCH_WINDOWS_BACKWARD;
            break;
        }
        return injections['_keyPressHandler'].call(this, keysym, action);
    };

    setKeybinding('switch-applications', Lang.bind(Main.wm, Main.wm._startWindowSwitcher));
    setKeybinding('switch-group', Lang.bind(Main.wm, Main.wm._startWindowSwitcher));
    setKeybinding('switch-applications-backward', Lang.bind(Main.wm, Main.wm._startWindowSwitcher));
    setKeybinding('switch-group-backward', Lang.bind(Main.wm, Main.wm._startWindowSwitcher));
}

function disable() {
    var prop;

    setKeybinding('switch-applications', Lang.bind(Main.wm, Main.wm._startAppSwitcher));
    setKeybinding('switch-group', Lang.bind(Main.wm, Main.wm._startAppSwitcher));
    setKeybinding('switch-applications-backward', Lang.bind(Main.wm, Main.wm._startAppSwitcher));
    setKeybinding('switch-group-backward', Lang.bind(Main.wm, Main.wm._startAppSwitcher));

    for (prop in injections)
        windowSwitcherProto[prop] = injections[prop];
}
